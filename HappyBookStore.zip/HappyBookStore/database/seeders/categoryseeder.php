<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class categoryseeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB ::table('categories')->insert([
                  
                ["category"=>"Fiction",],
                ["category"=>"Sci-fi"],
                ["category"=>"Fantasy"],
                ["category"=>"Romance"],
                ["category"=>"Adventure"],
                ["category"=>"Mystery"],
                ["category"=>"Horror"],
                ["category"=>"Thriller"],
                ["category"=>"Paranormal"],
                ["category"=>"History"]
                  
        ]);
    }
}
