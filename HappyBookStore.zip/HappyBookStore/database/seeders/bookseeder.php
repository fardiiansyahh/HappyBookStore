<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class bookseeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('books')->insert([
            [   
                'title' => 'Title1',
                'Category_id'=> 1
            ],
            [   
                'title' => 'Title2',
                'Category_id'=> 2
            ],
            [   
                'title' => 'Title3',
                'Category_id'=> 3
            ],
            [   
                'title' => 'Title4',
                'Category_id'=> 4
            ],
            [   
                'title' => 'Title5',
                'Category_id'=> 5
            ],
            [   
                'title' => 'Title6',
                'Category_id'=> 6
            ],
            [   
                'title' => 'Title7',
                'Category_id'=> 7
            ],
            [   
                'title' => 'Title8',
                'Category_id'=> 8
            ],
            [   
                'title' => 'Title9',
                'Category_id'=> 9
            ],
            [   
                'title' => 'Title10',
                'Category_id'=> 10
            ],
  ]);
    }
}
