<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class detailseeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('details')->insert([
            [   
                'book_id' => 1,
                'author' => 'Jason Kenneth Hauw',
                'publisher' => 'Pub',
                'year' => 2020,
                'description' => 'D'
            ],
            [   
                'book_id' => 2,
                'author' => 'Ricky',
                'publisher' => 'Publ',
                'year' => 2021,
                'description' => 'De'
            ],
            [   
                'book_id' => 3,
                'author' => 'Stef',
                'publisher' => 'Publi',
                'year' => 2100,
                'description' => 'Des'
            ],
            [   
                'book_id' => 4,
                'author' => 'Hen',
                'publisher' => 'Publis',
                'year' => 2001,
                'description' => 'Desc'
            ],
            [   
                'book_id' => 5,
                'author' => 'Aliya',
                'publisher' => 'Publish',
                'year' => 2001,
                'description' => 'Descr'
            ],
            [   
                'book_id' => 6,
                'author' => 'Ester',
                'publisher' => 'Publishe',
                'year' => 2012,
                'description' => 'Descri'
            ],
            [   
                'book_id' => 7,
                'author' => 'Nas',
                'publisher' => 'Publisher',
                'year' => 2021,
                'description' => 'Montero'
            ],
            [   
                'book_id' => 8,
                'author' => 'Republic',
                'publisher' => 'Run',
                'year' => 2025,
                'description' => 'Run Run Run'
            ],
            [   
                'book_id' => 9,
                'author' => 'Kes',
                'publisher' => 'Less',
                'year' => 2019,
                'description' => 'Of you'
            ],
            [   
                'book_id' => 9,
                'author' => 'Slip',
                'publisher' => 'knot',
                'year' => 2001,
                'description' => 'Solway Firth'
            ],
            [   
                'book_id' => 10,
                'author' => 'Author1',
                'publisher' => 'Publisher1',
                'year' => 2999,
                'description' => 'Something about the past'
            ]
            
        ]);
    }
}
