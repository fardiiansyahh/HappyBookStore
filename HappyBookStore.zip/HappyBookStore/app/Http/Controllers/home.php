<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Books;
use App\Models\Details;

class home extends Controller
{
    //
    public function getBook(){
        $homecontents = Category::join('Books','Books.category_id','=','categoryid')
        ->join('details','details.book_id','=','books.id')->get([
            'Books.title','Details.author'
        ]);
    }
}
