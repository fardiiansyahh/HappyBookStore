<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use app\models\Books;
use App\Models\Category;
use app\models\Details;

class categories extends Controller
{
    //
    public function getCategory(Request $request){
        // $categoriescontent = categories::join('Books','Books.category_id','=','categoryid')
        // ->join('details','details.book_id','=','books.id')->get([
        //     'Books.title','Details.author'
        // ]);
        $categories = Category::with(['book'])->where('íd', '=', $request->input('id'))->get()[0];
        return $categories;
    }
}
