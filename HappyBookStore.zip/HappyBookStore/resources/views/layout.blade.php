<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
    </script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
    <title>Home</title>
</head>

<body>
    <style>
    </style>

    <div class="bg-primary d-flex text-white justify-content-center">
        Happy Book Store
    </div>
    <div class=".navbar navbar-light bg-ligt"></div>

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand  {{ Request::Path() === '/home' ? : ''}}" href="/">Home</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
                aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            Category
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <li><a class="dropdown-item" href="#">Fiction</a></li>
                            <li><a class="dropdown-item" href="#">Sci-fi</a></li>
                            <li><a class="dropdown-item" href="#">Fantasy</a></li>
                            <li><a class="dropdown-item" href="#">Romance</a></li>
                            <li><a class="dropdown-item" href="#">Adventure</a></li>
                            <li><a class="dropdown-item" href="#">Mystery</a></li>
                            <li><a class="dropdown-item" href="#">Horror</a></li>
                            <li><a class="dropdown-item" href="#">Thriller</a></li>
                            <li><a class="dropdown-item" href="#">Paranormal</a></li>
                            <li><a class="dropdown-item" href="#">History</a></li>

                        </ul>
                    <li class="nav-item">
                        <a class="nav-link active {{ Request::Path() === 'contact' ? : ''}}" aria-current="page" href="/contact">Contact</a>
                    </li>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- CONTENT -->

    <div class="container mt-4">
        <div class="row">
            <div class="col-sm-2">
            </div>
            <div class="col-md-7 p-1">
                <h5 class="p-2 font- fw-bolder bg-warning">Book List</h4>
                    <div class="gap-2 d-flex justify-content-end">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Title</th>
                                    <th scope="col">Author</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Title1</td>
                                    <td>Jason Kenneth Hauw</td>
                                </tr>
                                <tr>
                                    <td>Title2</td>
                                    <td>Ricky</td>
                                </tr>
                                <tr>
                                    <td>Title3</td>
                                    <td>Stef</td>
                                </tr>
                                <tr>
                                    <td>Titl4</td>
                                    <td>Hen</td>
                                </tr>
                                <tr>
                                    <td>Title5</td>
                                    <td>Aliya</td>
                                </tr>

                            </tbody>
                        </table>

                    </div>
                    <div class="py-3 d-flex justify-content-end">
                    </div>
                    <button class="btnNextPrevious btn btn-primary" type="button">
                            <span><i class="bi bi-chevron-double-left"></i></span>
                            Previous
                        </button>

                        <button class="btnNextPrevious btn btn-primary" type="button">Next<span><i
                                    class="bi bi-chevron-double-right"></i></span></button>
            </div>
            <div class="col-md-2 p-1">
                <h5 class="p-2 fw-bolder bg-warning">Category</h5>
                <a class="d-block p-2 text-decoration-none" href="#">Fiction</a>
                <a class="d-block p-2 text-decoration-none" href="#">Sci-fi</a>
                <a class="d-block p-2 text-decoration-none" href="#">Fantasy</a>
                <a class="d-block p-2 text-decoration-none" href="#">Romance</a>
                <a class="d-block p-2 text-decoration-none" href="#">Adventure</a>
                <a class="d-block p-2 text-decoration-none" href="#">Mystery</a>
                <a class="d-block p-2 text-decoration-none" href="#">Horror</a>
                <a class="d-block p-2 text-decoration-none" href="#">Thriller</a>
                <a class="d-block p-2 text-decoration-none" href="#">Paranormal</a>
                <a class="d-block p-2 text-decoration-none" href="#">History</a>
            </div>
        </div>
    </div>

    <div class="bg-primary d-flex text-white justify-content-center">
        © Happy Book Store 2021
    </div>


</body>

</html>
